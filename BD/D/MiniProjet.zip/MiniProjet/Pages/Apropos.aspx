﻿<%@ Page Title="" Language="C#" MasterPageFile="~/MasterPage.master" AutoEventWireup="true" CodeFile="Apropos.aspx.cs" Inherits="Pages_Apropos" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" Runat="Server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" Runat="Server">
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="Contenu" Runat="Server">
       <h3>A propos</h3>
    <hr/>
    <br/>
     <p>Ce site est developpé pour illustrer les concepts vus dans le cadre du cours SQL.
        Il a été développé par  l'ensemble des etudiants AEC...<br/>
    </p>
</asp:Content>

